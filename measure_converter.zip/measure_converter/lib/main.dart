import 'package:flutter/material.dart';

void main() {
  runApp(MeasureConverterApp());
}

class MeasureConverterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Measure Converter',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MeasureConverterScreen(),
    );
  }
}

class MeasureConverterScreen extends StatefulWidget {
  @override
  _MeasureConverterScreenState createState() => _MeasureConverterScreenState();
}

class _MeasureConverterScreenState extends State<MeasureConverterScreen> {
  final TextEditingController _valueController = TextEditingController();
  String _fromUnit = 'meters';
  String _toUnit = 'feet';
  String _result = '';

  // Conversion rates
  final Map<String, double> _conversionRates = {
    'meters_to_feet': 3.28084,
    'feet_to_meters': 0.3048,
    'miles_to_kilometers': 1.60934,
    'kilometers_to_miles': 0.621371,
    'kilograms_to_pounds': 2.20462,
    'pounds_to_kilograms': 0.453592
  };

  void _convert() {
    double? inputValue = double.tryParse(_valueController.text);
    if (inputValue == null) {
      setState(() {
        _result = 'Please enter a valid number';
      });
      return;
    }

    String conversionKey = '${_fromUnit}_to_${_toUnit}';
    double conversionRate = _conversionRates[conversionKey] ?? 1.0;

    double convertedValue = inputValue * conversionRate;
    setState(() {
      _result = '${inputValue.toStringAsFixed(1)} $_fromUnit are ${convertedValue.toStringAsFixed(3)} $_toUnit';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Measures Converter')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Value', style: TextStyle(fontSize: 20)),
            TextField(
              controller: _valueController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(hintText: 'Enter value'),
            ),
            SizedBox(height: 20),
            Text('From', style: TextStyle(fontSize: 20)),
            DropdownButton<String>(
              value: _fromUnit,
              items: [
                'meters', 'feet', 'miles', 'kilometers', 'kilograms', 'pounds'
              ].map((String unit) {
                return DropdownMenuItem<String>(
                  value: unit,
                  child: Text(unit),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _fromUnit = value!;
                });
              },
            ),
            SizedBox(height: 20),
            Text('To', style: TextStyle(fontSize: 20)),
            DropdownButton<String>(
              value: _toUnit,
              items: [
                'meters', 'feet', 'miles', 'kilometers', 'kilograms', 'pounds'
              ].map((String unit) {
                return DropdownMenuItem<String>(
                  value: unit,
                  child: Text(unit),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _toUnit = value!;
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _convert,
              child: Text('Convert'),
            ),
            SizedBox(height: 20),
            Text(_result, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
